package com.codingdojo.zookeeper;

public class GorillaTest {
    public static void main(String[] args) {
    	Gorilla g = new Gorilla();
    	g.throwSomethign();
    	g.throwSomethign();
    	g.throwSomethign();
    	g.eatBananas();
    	g.eatBananas();
    	g.climb();
    	g.displayEnergy();
    }
}
