package com.codingdojo.phone;

public interface Ringable {
	String ring();
	String unlock();
}
