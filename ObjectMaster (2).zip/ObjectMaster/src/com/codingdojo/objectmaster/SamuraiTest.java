package com.codingdojo.objectmaster;

public class SamuraiTest {
	public Integer noOfSamurai = 0;

}
